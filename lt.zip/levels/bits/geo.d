build/us/levels/bits/geo.o: levels/bits/geo.c include/ultra64.h \
 include/libc/math.h include/PR/ultratypes.h include/PR/os_exception.h \
 include/PR/os_misc.h include/PR/os_rdp.h include/PR/os_thread.h \
 include/PR/ultratypes.h include/PR/os_time.h include/PR/os_message.h \
 include/PR/os_cont.h include/PR/os_message.h include/PR/os_tlb.h \
 include/PR/sptask.h include/PR/ucode.h include/PR/os_cache.h \
 include/PR/os_vi.h include/PR/os_pi.h include/PR/os_internal.h \
 include/PR/mbi.h include/platform_info.h include/PR/gbi.h \
 include/PR/abi.h include/PR/os_eeprom.h include/PR/os_libc.h \
 include/PR/gu.h include/PR/os_ai.h include/PR/libaudio.h \
 include/PR/abi.h include/PR/libultra.h include/sm64.h include/types.h \
 include/macros.h include/platform_info.h include/config.h \
 include/object_fields.h include/object_constants.h \
 include/audio_defines.h include/model_ids.h \
 include/mario_animation_ids.h include/mario_geo_switch_case_ids.h \
 include/surface_terrains.h include/geo_commands.h \
 include/command_macros_base.h src/game/shadow.h include/types.h \
 src/game/object_helpers.h src/game/object_helpers2.h \
 src/game/behavior_actions.h src/game/segment2.h src/game/mario_misc.h \
 src/game/mario_actions_cutscene.h src/game/level_geo.h \
 src/game/geo_misc.h src/game/camera.h src/game/area.h \
 src/engine/geo_layout.h src/game/memory.h src/engine/graph_node.h \
 include/level_table.h levels/level_defines.h src/game/moving_texture.h \
 src/game/screen_transition.h src/game/paintings.h levels/bits/header.h \
 levels/bits/areas/1/2/geo.inc.c levels/bits/areas/1/3/geo.inc.c \
 levels/bits/areas/1/4/geo.inc.c levels/bits/areas/1/5/geo.inc.c \
 levels/bits/areas/1/6/geo.inc.c levels/bits/areas/1/7/geo.inc.c \
 levels/bits/areas/1/8/geo.inc.c levels/bits/areas/1/9/geo.inc.c \
 levels/bits/areas/1/10/geo.inc.c levels/bits/areas/1/11/geo.inc.c \
 levels/bits/areas/1/12/geo.inc.c levels/bits/areas/1/13/geo.inc.c \
 levels/bits/areas/1/14/geo.inc.c levels/bits/areas/1/15/geo.inc.c \
 levels/bits/areas/1/16/geo.inc.c levels/bits/areas/1/17/geo.inc.c \
 levels/bits/areas/1/18/geo.inc.c levels/bits/areas/1/19/geo.inc.c \
 levels/bits/areas/1/20/geo.inc.c levels/bits/areas/1/21/geo.inc.c \
 levels/bits/areas/1/22/geo.inc.c levels/bits/areas/1/23/geo.inc.c \
 levels/bits/areas/1/24/geo.inc.c levels/bits/areas/1/25/geo.inc.c \
 levels/bits/areas/1/26/geo.inc.c levels/bits/areas/1/27/geo.inc.c \
 levels/bits/areas/1/28/geo.inc.c levels/bits/areas/1/29/geo.inc.c \
 levels/bits/areas/1/30/geo.inc.c levels/bits/areas/1/31/geo.inc.c \
 levels/bits/areas/1/32/geo.inc.c levels/bits/areas/1/geo.inc.c
include/ultra64.h:
include/libc/math.h:
include/PR/ultratypes.h:
include/PR/os_exception.h:
include/PR/os_misc.h:
include/PR/os_rdp.h:
include/PR/os_thread.h:
include/PR/ultratypes.h:
include/PR/os_time.h:
include/PR/os_message.h:
include/PR/os_cont.h:
include/PR/os_message.h:
include/PR/os_tlb.h:
include/PR/sptask.h:
include/PR/ucode.h:
include/PR/os_cache.h:
include/PR/os_vi.h:
include/PR/os_pi.h:
include/PR/os_internal.h:
include/PR/mbi.h:
include/platform_info.h:
include/PR/gbi.h:
include/PR/abi.h:
include/PR/os_eeprom.h:
include/PR/os_libc.h:
include/PR/gu.h:
include/PR/os_ai.h:
include/PR/libaudio.h:
include/PR/abi.h:
include/PR/libultra.h:
include/sm64.h:
include/types.h:
include/macros.h:
include/platform_info.h:
include/config.h:
include/object_fields.h:
include/object_constants.h:
include/audio_defines.h:
include/model_ids.h:
include/mario_animation_ids.h:
include/mario_geo_switch_case_ids.h:
include/surface_terrains.h:
include/geo_commands.h:
include/command_macros_base.h:
src/game/shadow.h:
include/types.h:
src/game/object_helpers.h:
src/game/object_helpers2.h:
src/game/behavior_actions.h:
src/game/segment2.h:
src/game/mario_misc.h:
src/game/mario_actions_cutscene.h:
src/game/level_geo.h:
src/game/geo_misc.h:
src/game/camera.h:
src/game/area.h:
src/engine/geo_layout.h:
src/game/memory.h:
src/engine/graph_node.h:
include/level_table.h:
levels/level_defines.h:
src/game/moving_texture.h:
src/game/screen_transition.h:
src/game/paintings.h:
levels/bits/header.h:
levels/bits/areas/1/2/geo.inc.c:
levels/bits/areas/1/3/geo.inc.c:
levels/bits/areas/1/4/geo.inc.c:
levels/bits/areas/1/5/geo.inc.c:
levels/bits/areas/1/6/geo.inc.c:
levels/bits/areas/1/7/geo.inc.c:
levels/bits/areas/1/8/geo.inc.c:
levels/bits/areas/1/9/geo.inc.c:
levels/bits/areas/1/10/geo.inc.c:
levels/bits/areas/1/11/geo.inc.c:
levels/bits/areas/1/12/geo.inc.c:
levels/bits/areas/1/13/geo.inc.c:
levels/bits/areas/1/14/geo.inc.c:
levels/bits/areas/1/15/geo.inc.c:
levels/bits/areas/1/16/geo.inc.c:
levels/bits/areas/1/17/geo.inc.c:
levels/bits/areas/1/18/geo.inc.c:
levels/bits/areas/1/19/geo.inc.c:
levels/bits/areas/1/20/geo.inc.c:
levels/bits/areas/1/21/geo.inc.c:
levels/bits/areas/1/22/geo.inc.c:
levels/bits/areas/1/23/geo.inc.c:
levels/bits/areas/1/24/geo.inc.c:
levels/bits/areas/1/25/geo.inc.c:
levels/bits/areas/1/26/geo.inc.c:
levels/bits/areas/1/27/geo.inc.c:
levels/bits/areas/1/28/geo.inc.c:
levels/bits/areas/1/29/geo.inc.c:
levels/bits/areas/1/30/geo.inc.c:
levels/bits/areas/1/31/geo.inc.c:
levels/bits/areas/1/32/geo.inc.c:
levels/bits/areas/1/geo.inc.c:
