build/us/actors/group0_geo.o: actors/group0_geo.c include/ultra64.h \
 include/libc/math.h include/PR/ultratypes.h include/PR/os_exception.h \
 include/PR/os_misc.h include/PR/os_rdp.h include/PR/os_thread.h \
 include/PR/ultratypes.h include/PR/os_time.h include/PR/os_message.h \
 include/PR/os_cont.h include/PR/os_message.h include/PR/os_tlb.h \
 include/PR/sptask.h include/PR/ucode.h include/PR/os_cache.h \
 include/PR/os_vi.h include/PR/os_pi.h include/PR/os_internal.h \
 include/PR/mbi.h include/platform_info.h include/PR/gbi.h \
 include/PR/abi.h include/PR/os_eeprom.h include/PR/os_libc.h \
 include/PR/gu.h include/PR/os_ai.h include/PR/libaudio.h \
 include/PR/abi.h include/PR/libultra.h include/sm64.h include/types.h \
 include/macros.h include/platform_info.h include/config.h \
 include/object_fields.h include/object_constants.h \
 include/audio_defines.h include/model_ids.h \
 include/mario_animation_ids.h include/mario_geo_switch_case_ids.h \
 include/surface_terrains.h include/geo_commands.h \
 include/command_macros_base.h src/game/shadow.h include/types.h \
 src/game/object_helpers.h src/game/object_helpers2.h \
 src/game/behavior_actions.h src/game/segment2.h src/game/mario_misc.h \
 src/game/mario_actions_cutscene.h include/make_const_nonconst.h \
 actors/common1.h actors/group0.h actors/bubble/geo.inc.c \
 actors/walk_smoke/geo.inc.c actors/burn_smoke/geo.inc.c \
 actors/stomp_smoke/geo.inc.c actors/water_wave/geo.inc.c \
 actors/sparkle/geo.inc.c actors/water_splash/geo.inc.c \
 actors/sparkle_animation/geo.inc.c actors/mario/geo.inc.c \
 actors/kermit/geo.inc.c actors/peach_2/geo.inc.c actors/imbie/geo.inc.c \
 actors/thwomp/geo.inc.c actors/kappa/geo.inc.c
include/ultra64.h:
include/libc/math.h:
include/PR/ultratypes.h:
include/PR/os_exception.h:
include/PR/os_misc.h:
include/PR/os_rdp.h:
include/PR/os_thread.h:
include/PR/ultratypes.h:
include/PR/os_time.h:
include/PR/os_message.h:
include/PR/os_cont.h:
include/PR/os_message.h:
include/PR/os_tlb.h:
include/PR/sptask.h:
include/PR/ucode.h:
include/PR/os_cache.h:
include/PR/os_vi.h:
include/PR/os_pi.h:
include/PR/os_internal.h:
include/PR/mbi.h:
include/platform_info.h:
include/PR/gbi.h:
include/PR/abi.h:
include/PR/os_eeprom.h:
include/PR/os_libc.h:
include/PR/gu.h:
include/PR/os_ai.h:
include/PR/libaudio.h:
include/PR/abi.h:
include/PR/libultra.h:
include/sm64.h:
include/types.h:
include/macros.h:
include/platform_info.h:
include/config.h:
include/object_fields.h:
include/object_constants.h:
include/audio_defines.h:
include/model_ids.h:
include/mario_animation_ids.h:
include/mario_geo_switch_case_ids.h:
include/surface_terrains.h:
include/geo_commands.h:
include/command_macros_base.h:
src/game/shadow.h:
include/types.h:
src/game/object_helpers.h:
src/game/object_helpers2.h:
src/game/behavior_actions.h:
src/game/segment2.h:
src/game/mario_misc.h:
src/game/mario_actions_cutscene.h:
include/make_const_nonconst.h:
actors/common1.h:
actors/group0.h:
actors/bubble/geo.inc.c:
actors/walk_smoke/geo.inc.c:
actors/burn_smoke/geo.inc.c:
actors/stomp_smoke/geo.inc.c:
actors/water_wave/geo.inc.c:
actors/sparkle/geo.inc.c:
actors/water_splash/geo.inc.c:
actors/sparkle_animation/geo.inc.c:
actors/mario/geo.inc.c:
actors/kermit/geo.inc.c:
actors/peach_2/geo.inc.c:
actors/imbie/geo.inc.c:
actors/thwomp/geo.inc.c:
actors/kappa/geo.inc.c:
