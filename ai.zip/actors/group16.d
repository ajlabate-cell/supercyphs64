build/us/actors/group16.o: actors/group16.c include/ultra64.h \
 include/libc/math.h include/PR/ultratypes.h include/PR/os_exception.h \
 include/PR/os_misc.h include/PR/os_rdp.h include/PR/os_thread.h \
 include/PR/ultratypes.h include/PR/os_time.h include/PR/os_message.h \
 include/PR/os_cont.h include/PR/os_message.h include/PR/os_tlb.h \
 include/PR/sptask.h include/PR/ucode.h include/PR/os_cache.h \
 include/PR/os_vi.h include/PR/os_pi.h include/PR/os_internal.h \
 include/PR/mbi.h include/platform_info.h include/PR/gbi.h \
 include/PR/abi.h include/PR/os_eeprom.h include/PR/os_libc.h \
 include/PR/gu.h include/PR/os_ai.h include/PR/libaudio.h \
 include/PR/abi.h include/PR/libultra.h include/sm64.h include/types.h \
 include/macros.h include/platform_info.h include/config.h \
 include/object_fields.h include/object_constants.h \
 include/audio_defines.h include/model_ids.h \
 include/mario_animation_ids.h include/mario_geo_switch_case_ids.h \
 include/surface_terrains.h include/surface_terrains.h \
 include/geo_commands.h include/command_macros_base.h src/game/shadow.h \
 include/types.h src/game/object_helpers.h src/game/object_helpers2.h \
 src/game/behavior_actions.h src/game/segment2.h src/game/mario_misc.h \
 src/game/mario_actions_cutscene.h include/make_const_nonconst.h \
 actors/chillychief/model.inc.c \
 build/us/actors/chillychief/chill_bully_left_side.rgba16.inc.c \
 build/us/actors/chillychief/chill_bully_right_side.rgba16.inc.c \
 build/us/actors/chillychief/chill_bully_eye.rgba16.inc.c \
 actors/chillychief/anims/data.inc.c \
 actors/chillychief/anims/anim_060032EC.inc.c \
 actors/chillychief/anims/anim_06003420.inc.c \
 actors/chillychief/anims/anim_060035E0.inc.c \
 actors/chillychief/anims/anim_0600373C.inc.c \
 actors/chillychief/geo.inc.c actors/chillychief/anims/table.inc.c \
 actors/moneybag/model.inc.c \
 build/us/actors/moneybag/moneybag_mouth.rgba16.inc.c \
 build/us/actors/moneybag/moneybag_eyes.rgba16.inc.c \
 actors/moneybag/anims/data.inc.c \
 actors/moneybag/anims/anim_06005AD8.inc.c \
 actors/moneybag/anims/anim_06005BEC.inc.c \
 actors/moneybag/anims/anim_06005C98.inc.c \
 actors/moneybag/anims/anim_06005D3C.inc.c \
 actors/moneybag/anims/anim_06005E44.inc.c \
 actors/moneybag/anims/table.inc.c
include/ultra64.h:
include/libc/math.h:
include/PR/ultratypes.h:
include/PR/os_exception.h:
include/PR/os_misc.h:
include/PR/os_rdp.h:
include/PR/os_thread.h:
include/PR/ultratypes.h:
include/PR/os_time.h:
include/PR/os_message.h:
include/PR/os_cont.h:
include/PR/os_message.h:
include/PR/os_tlb.h:
include/PR/sptask.h:
include/PR/ucode.h:
include/PR/os_cache.h:
include/PR/os_vi.h:
include/PR/os_pi.h:
include/PR/os_internal.h:
include/PR/mbi.h:
include/platform_info.h:
include/PR/gbi.h:
include/PR/abi.h:
include/PR/os_eeprom.h:
include/PR/os_libc.h:
include/PR/gu.h:
include/PR/os_ai.h:
include/PR/libaudio.h:
include/PR/abi.h:
include/PR/libultra.h:
include/sm64.h:
include/types.h:
include/macros.h:
include/platform_info.h:
include/config.h:
include/object_fields.h:
include/object_constants.h:
include/audio_defines.h:
include/model_ids.h:
include/mario_animation_ids.h:
include/mario_geo_switch_case_ids.h:
include/surface_terrains.h:
include/surface_terrains.h:
include/geo_commands.h:
include/command_macros_base.h:
src/game/shadow.h:
include/types.h:
src/game/object_helpers.h:
src/game/object_helpers2.h:
src/game/behavior_actions.h:
src/game/segment2.h:
src/game/mario_misc.h:
src/game/mario_actions_cutscene.h:
include/make_const_nonconst.h:
actors/chillychief/model.inc.c:
build/us/actors/chillychief/chill_bully_left_side.rgba16.inc.c:
build/us/actors/chillychief/chill_bully_right_side.rgba16.inc.c:
build/us/actors/chillychief/chill_bully_eye.rgba16.inc.c:
actors/chillychief/anims/data.inc.c:
actors/chillychief/anims/anim_060032EC.inc.c:
actors/chillychief/anims/anim_06003420.inc.c:
actors/chillychief/anims/anim_060035E0.inc.c:
actors/chillychief/anims/anim_0600373C.inc.c:
actors/chillychief/geo.inc.c:
actors/chillychief/anims/table.inc.c:
actors/moneybag/model.inc.c:
build/us/actors/moneybag/moneybag_mouth.rgba16.inc.c:
build/us/actors/moneybag/moneybag_eyes.rgba16.inc.c:
actors/moneybag/anims/data.inc.c:
actors/moneybag/anims/anim_06005AD8.inc.c:
actors/moneybag/anims/anim_06005BEC.inc.c:
actors/moneybag/anims/anim_06005C98.inc.c:
actors/moneybag/anims/anim_06005D3C.inc.c:
actors/moneybag/anims/anim_06005E44.inc.c:
actors/moneybag/anims/table.inc.c:
